How to execute the file:

Open Google colab and run two files. :)